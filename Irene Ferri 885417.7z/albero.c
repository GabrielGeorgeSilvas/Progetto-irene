#include "albero.h"

node * new_node(int nIndice,node* nPadre) /*aggiungi semplicemente il dato riguardante la sequenza e aggiungilo al nodo*/
{
    node *new_node = malloc(sizeof(node));

    /*l'if sottostante è condizione semplificata di new_node==NULL --> errore*/
    if ( new_node ) 
	{ 
        new_node->padre=nPadre;
        new_node->fratello = NULL;
        new_node->figlio = NULL;
        new_node->indice = nIndice;
        new_node->peso=0;
    }
    return new_node;
}

node * add_fratello(node * n, int nIndice) /*funzione aggiungi fratello*/
{
    if ( n == NULL ) /*casistica di errato inserimento*/
        return NULL;

    while (n->fratello) /*ciclo per scorrere il numero dinamico di fratelli per inserimento in coda dell'ultimo fratello arrivato*/
        n = n->fratello;

    return (n->fratello = new_node(nIndice,n->padre)); /*aggiunta del fratello*/
}

node * add_figlio(node * n, int nIndice)
{
    if ( n == NULL )
        return NULL;

    if ( n->figlio ) /*controllo se figlio gia presente (n->figlio!=NULL) ,se si allora richiamo aggiungi fratello*/
        return add_fratello(n->figlio, nIndice);
    else
        return (n->figlio = new_node(nIndice,n)); /*caso del primo figlio ,richiamo aggiungi figlio non aggiungi fratello*/
}

void pre_order_traversal_Result(node* root,printResult *pR) 
{
    if(root == NULL) return;
        pR[root->indice].peso=root->peso;
        if(root->padre!=NULL) pR[root->indice].padre=root->padre->indice;
        else pR[root->indice].padre=0;
        pre_order_traversal_Result(root->fratello,pR);
        pre_order_traversal_Result(root->figlio,pR);
}

void pre_order_traversal(node* root) 
{
	node *aux;
	
    if(root == NULL) return;
    else if(root->padre==NULL && root->figlio ==NULL) printf("\n%d (peso %d) HAS NO CHILD AND IS GOD FATHER ",root->indice,root->peso);
    else if(root->figlio==NULL) printf("\n%d (peso %d) HAS NO CHILD and father %d",root->indice,root->peso,root->padre->indice);
    else
	{
        printf("\n%d (peso %d) HAS CHILD -> ",root->indice,root->peso);
        aux=root->figlio;
        while (aux)
		{
            printf("__%d__",aux->indice);
            aux=aux->fratello;
        }
        if(root->padre!=NULL) printf("and father %d",root->padre->indice);
        else printf(" AND IS GOD FATHER");
   }
    pre_order_traversal(root->fratello);
    pre_order_traversal(root->figlio);
}

node* searchTree(node *root,int nIndiceToSearch)
{
    if(root->indice==nIndiceToSearch) /*if root->data is x then the element is found*/
        return root;
    else 
	{
        if (root->fratello != NULL) 
		{
            node* aux = searchTree(root->fratello,nIndiceToSearch);
            if (aux != NULL) 
			{
                return aux;
            }
        }
        if (root->figlio != NULL) 
		{
            return searchTree(root->figlio,nIndiceToSearch);
        }
    }
    return NULL;
}

void deleteTree(node* root)  
{  
    if (root == NULL) return;  
  
    /* elimina entrambi i sotto alberi */
    deleteTree(root->figlio);  
    deleteTree(root->fratello);  
      
    free(root);
} 

node* createTree(int *padri, int dim,int indiceRoot,node *root)
{
	int i;
	
    if(indiceRoot==1)root=new_node(indiceRoot,NULL);
    for(i=0;i<=dim;i++){
        if(padri[i]==indiceRoot)
		{
            padri[i]=3000;
            createTree(padri,dim,i+2,add_figlio(root,i+2));      
        }
    }
    return root;
}

int findPeso(node* root)
{
    if(root==NULL) return 0;
    else if(root->figlio==NULL) return root->peso=1;
    else
	{
            node *aux=root->figlio;
            root->peso=1+findPeso(root->figlio);
            while(aux->fratello)
			{
                root->peso+=findPeso(aux->fratello);
                aux=aux->fratello;
            }
            return root->peso;
    }
}

node* switchFatherSon(node* toStartFrom)
{
    if(toStartFrom->padre==NULL)
	{
        return toStartFrom;
    }
    else{ 
        node *auxPadre=toStartFrom->padre;
        node *auxFiglio=toStartFrom->figlio;
        node *aux;
        aux=toStartFrom;
        while(aux)
		{
                aux->padre=NULL;
                aux=aux->fratello;
        }
        toStartFrom->figlio=switchFatherSon(auxPadre);
        auxPadre->padre=toStartFrom;
        if(auxPadre->padre==auxPadre->figlio) auxPadre->figlio = NULL;
        if(auxPadre->figlio!=NULL && auxPadre->figlio!=toStartFrom)
		{
            aux=auxPadre->figlio;
            while(aux->fratello!=toStartFrom)aux=aux->fratello;
            aux->fratello=NULL;
        }
        while(auxPadre->fratello)
		{
            auxPadre->fratello->padre=toStartFrom;
            auxPadre=auxPadre->fratello;
        }
        auxPadre->fratello=auxFiglio;
        auxPadre->peso=findPeso(auxPadre);
        toStartFrom->peso=findPeso(toStartFrom);

        return toStartFrom;
    }
}

node* getMostRappresentiveRoot(node *root)
{
    if (root==NULL) return NULL;
    else
	{
        node *mostRappresentive=root->figlio;
        while(mostRappresentive!=NULL)
		{
            if((mostRappresentive->peso > (root->peso)/2) || (mostRappresentive->peso == (root->peso /2) && mostRappresentive->indice < root->indice))
			{
                root=getMostRappresentiveRoot(switchFatherSon(mostRappresentive));
            }
             mostRappresentive=mostRappresentive->fratello; 
        }  
        return root;  
    }
}

void printFinalResult(printResult *pR,int n)
{
    int i;
    for(i=1;i<=n;i++){
        printf("\n%d %d ",i,pR[i].peso);
        if(pR[i].padre==0) printf(" *");
        else printf("%d",pR[i].padre);
    }
}
