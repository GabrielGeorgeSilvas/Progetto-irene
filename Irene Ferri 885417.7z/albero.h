#ifndef __albero_h
#define __albero_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kruskal.h"

#define ROW_LENGTH 256

#define boolean int
#define TRUE  1
#define FALSE 0


#define NO_OP  ' '
#define NO_VAL 0.0

#define NO_NODE  NULL
#define NO_TREE  NULL

typedef struct _node node;

struct _node
{
  int indice; /*corrispondente a codice, ho ovviato i dati riguardanti la sequenza li lascio inserire a te*/
  int peso;
  node *padre;
  node *fratello;
  node *figlio;
};

struct printResult{
    int peso;
    int padre;
};

typedef struct printResult printResult;

/*funzione crea nodo, può essere utilizzato per inizializzare l'albero (una specie di crea albero alla prima chiamata )*/
node * new_node(int,node*);

/*funzione aggiungi fratello, restituisce il puntatore al nodo fratello da inserire nell'albero*/
node * add_fratello(node *, int);

/*funzione aggiungi figlio, restituisce il puntatore al nodo fratello da inserire nell'albero*/
node * add_figlio(node *, int);

/*funzione di stampa albero, rappresentazione modificabile (RICORSIVA)*/
void pre_order_traversal_Result(node *,printResult*);
void pre_order_traversal(node*);

/*funzione di ricerca albero,in base all'indice fornito per arg restituisce un puntatore al nodo stesso (RICORSIVA)*/
/*fondamentale per l'inseriemento "on going" o per estrapolare informazioni */
node* searchTree(node *,int);

/*funzione di terminazione Albero con deallocazione della memoria, utlima stampa dei nodi contenuti nell'albero da terminare*/
void deleteTree(node *);

/*crea l'albero*/
node* createTree(int*,int,int,node*);

/*setta i pesi dei vari nodi dell'albero*/
int findPeso(node*);

/*scambia padre e figlio*/
node* switchFatherSon(node*);

/*rialloca la radice*/
node* getMostRappresentiveRoot(node*);

/*stampa nell'ordine nodo,peso e padre*/
void printFinalResult(printResult*,int);

#endif
