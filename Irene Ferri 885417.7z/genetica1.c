/*genetica.c*/

/* Direttive */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "listaarchi.h"
#include "grafo-la.h"
#include "kruskal.h"
#include "albero.h"
#include "listacluster.h"

typedef vchar *codice;

/* Legge dalla linea di comando il file che contiene il grafo */
void InterpretaLineaComando (int argc, char *argv[], char *filedati);

/*Carico un array di codici genetici*/
void CaricaCodici_genetici(char *filedati,codice *sequenze,grafo *pG,int *lung,int *specie);

/*Allocazione lista di codici*/
void Allocacodici(codice *sequenze,int n,int l);

/*Creo gli archi pesati*/
void CaricaGrafo(codice sequenze,grafo *pG,int n,int l);

/*Calcola la frequanza con cui compaiono i cratteri A,C,G,T su tutti i codici genetici*/
void Frequenza(codice sequenze,int n,int l);

/*Calcola la frequanza con cui compaiono i cratteri delle coppie date da A,C,G,T su tutti i codici genetici*/
void FrequenzaCoppie(codice sequenze,int n,int l);

/*costruisce il vettore padre e stampa la rappresentazione compatta*/
void Compattamento(codice sequenze,vint padre,soluzioneMST *S,int n,int l);

/* Ordina il l'array di stringhe sequenze compreso fra s e d con l'algoritmo QuickSort */
void QuickSort(codice sequenze, int s, int d,int l);

/* Partiziona l'array di stringhe sequenze fra s e d in un sottovettore sequenze[s,q] di elementi <= pivot
   e un sottovettore sequenze[q+1,d] di elementi > pivot, pone il pivot fra i due sottovettori
   e restituisce l'indice finale del pivot */
int Partition(codice sequenze, int s, int d,int l);

void DeallocaCodiceGenetico(codice *sequenze, int n);

int main (int argc, char *argv[])
{
  char filedati[ROW_LENGTH];
  codice sequenze; 
  grafo G;
  soluzioneMST S;
  int i,j;
  int lung,specie;
  vint padre;
  node *T=NULL;
  elemento *cluster=NULL;
  printResult *pR;
  
  /* Legge da linea di comando il file che contiene il grafo */
  InterpretaLineaComando(argc,argv,filedati);
  
  /* Carica in un albero i codici genetici letti da file*/
  CaricaCodici_genetici(filedati,&sequenze,&G,&lung,&specie);
  
  /*Creo gli archi pesati*/
  CaricaGrafo(sequenze,&G,G.n,lung);

  /*Calcola la frequenza con cui appare ogni aminoacido*/
  Frequenza(sequenze,G.n,lung);

  /*Calcola la frequenza delle coppie di aminoacidi*/
  FrequenzaCoppie(sequenze,G.n,lung);
  
  /* Crea una soluzione vuota */
  CreaSoluzione(G.n-1,&S);

  /* Risolve il problema dell'albero ricoprente minimo sul grafo G */
  Kruskal(&G,&S);

  /*costruisce il vettore padre e stampa la rappresentazione compatta*/
  padre=malloc(G.n-1*sizeof(int));
  
  Compattamento(sequenze,padre,&S,G.n,lung);
  
  /*creo l'albero*/
  T = createTree(padre,G.n-1,1,T);
  
  /*carico il peso*/
  findPeso(T);
  
  /*ricostruisco l'albero radicandolo*/
  T=getMostRappresentiveRoot(T);
  
  /*stampa*/
  pR=malloc(G.n*sizeof(printResult));
  pre_order_traversal_Result(T,pR);
  printFinalResult(pR,G.n);
  printf("\n");
  
  /*Creo e carico una lista di cluster*/
  cluster=caricalista_cluster(specie,G.n,lung,sequenze);
  
  /*Riallocamento dell'elemento rappresentativo*/
  cluster=riallocamento_rappresentante(cluster,specie,sequenze,lung);
  
  /*Stampo i cluster*/
  stampalista_cluster(cluster,specie);
  
  /*file dati inizale in ordine alfabetico*/
  QuickSort(sequenze,1,G.n,lung);
  for(i=1;i<=G.n;i++)
  {
	  for(j=0;j<lung;j++)
		  printf("%c",sequenze[i][j]);
	  printf("\n");
  }

  /* Dealloca le strutture dati dinamiche */
  deleteTree(T);
  DistruggeSoluzione(&S);
  distruggegrafo(&G);
  DeallocaCodiceGenetico(&sequenze,G.n);
  
  return EXIT_SUCCESS;
}

/* Legge dalla linea di comando il file che contiene il grafo */
void InterpretaLineaComando (int argc, char *argv[], char *filedati)
{

	if (argc >2)
	{
		fprintf(stderr,"Errore nella linea di comando!\n");
		exit(EXIT_FAILURE);
	}

	strcpy(filedati,argv[1]);
}

void Allocacodici(codice *sequenze,int n,int l)
{
	int i;
	
	/* Alloca la lista di codici */
	(*sequenze) = (codice) calloc(n,sizeof(vchar));
	if (sequenze == NULL)
	{
		fprintf(stderr,"Errore nell'allocazione di una lista di codici!\n");
		exit(EXIT_FAILURE);
	}
	  
	/* Alloca ogni codice*/
	for (i = 1; i <= n; i++)
	{
		(*sequenze)[i] = (vchar) calloc(l,sizeof(char));
		if ((*sequenze)[i] == NULL)
		{
		  fprintf(stderr,"Errore nell'allocazione della %d -esimo codice!\n",i);
		  exit(EXIT_FAILURE);
		}
	}
}

void CaricaCodici_genetici(char *filedati,codice *sequenze,grafo *pG,int *lung,int *specie)
{
	FILE *fp;
	int i,num,l,s;
	
	/*apre in lettura il filedati*/
	fp = fopen(filedati,"r");
	if (fp == NULL)
	{
		fprintf(stderr,"Errore nell'apertura del file %s!\n",filedati);
		exit(EXIT_FAILURE);
	}
	
	/* Legge il file una riga alla volta */
	fscanf(fp,"%d",&num);
	fscanf(fp,"%d",&l);
	*lung=l;
	fscanf(fp,"%d",&s);
	*specie=s;
	
	/* Alloca spazio per la lista di codici */
	Allocacodici(sequenze,num+1,l);
	
	for (i = 1; i <= num; i++)
	{
		fscanf(fp,"%s[^\n]\n",(*sequenze)[i]);
	}
	
	creagrafo(num, pG);
	
	/*chiude il filedati*/
	fclose(fp);	  
}

/*Creo gli archi pesati*/
void CaricaGrafo(codice sequenze,grafo *pG,int n,int l)
{
	int k,i,j,diff;
	
	for(k=1;k<=n;k++)
	{
		for(i=1;i<=n;i++)
		{
			diff=0;
			for(j=0;j<l;j++)
			{
				if((sequenze[k][j]!=sequenze[i][j])&&(k<i))
				{
					diff++;
				}
			}
			if(k<i)
			{
				insarco_ordinato(k,i,diff,pG,sequenze,l);
			}
		}
	}
}

void Frequenza(codice sequenze,int n,int l)
{
	int i,j,tot;
	double a=0,c=0,g=0,t=0;
	
	tot=n*l;
	
	for(i=1;i<=n;i++)
	{
		for(j=0;j<l;j++)
		{
			if(sequenze[i][j]=='A')
				a++;
			else if(sequenze[i][j]=='C')
				c++;
			else if(sequenze[i][j]=='G')
				g++;
			else if(sequenze[i][j]=='T')
				t++;
			else
				printf("errore nella sequenza, aminoacido non riconosciuto");
		}
	}
	
	printf("A %.3f\nC %.3f\nG %.3f\nT %.3f\n",a/tot,c/tot,g/tot,t/tot);
}

void FrequenzaCoppie(codice sequenze,int n,int l)
{
	int i,j,tot;
	double aa=0,ac=0,ag=0,at=0;
	double ca=0,cc=0,cg=0,ct=0;
	double ga=0,gc=0,gg=0,gt=0;
	double ta=0,tc=0,tg=0,tt=0;
	
	tot=n*(l-1);
	
	for(i=1;i<=n;i++)
	{
		for(j=0;j<l;j++)
		{
			if(sequenze[i][j]=='A')
			{
				if(sequenze[i][j+1]=='A')
					aa++;
				else if(sequenze[i][j+1]=='C')
					ac++;
				else if(sequenze[i][j+1]=='G')
					ag++;
				else if(sequenze[i][j+1]=='T')
					at++;
			}				
			else if(sequenze[i][j]=='C')
			{
				if(sequenze[i][j+1]=='A')
					ca++;
				else if(sequenze[i][j+1]=='C')
					cc++;
				else if(sequenze[i][j+1]=='G')
					cg++;
				else if(sequenze[i][j+1]=='T')
					ct++;
			}				
			
			else if(sequenze[i][j]=='G')
			{
				if(sequenze[i][j+1]=='A')
					ga++;
				else if(sequenze[i][j+1]=='C')
					gc++;
				else if(sequenze[i][j+1]=='G')
					gg++;
				else if(sequenze[i][j+1]=='T')
					gt++;
				
			}				
			else if(sequenze[i][j]=='T')
			{
				if(sequenze[i][j+1]=='A')
					ta++;
				else if(sequenze[i][j+1]=='C')
					tc++;
				else if(sequenze[i][j+1]=='G')
					tg++;
				else if(sequenze[i][j+1]=='T')
					tt++;
			} 
			else
				printf("errore nella sequenza, aminoacido non riconosciuto");
		}
	}
	
	printf("    A\t   C\t   G\t   T\nA %.3f\t %.3f\t %.3f\t %.3f\nC %.3f\t %.3f\t %.3f\t %.3f\nG %.3f\t %.3f\t %.3f\t %.3f\nT %.3f\t %.3f\t %.3f\t %.3f\n",aa/tot,ac/tot,ag/tot,at/tot,ca/tot,cc/tot,cg/tot,ct/tot,ga/tot,gc/tot,gg/tot,gt/tot,ta/tot,tc/tot,tg/tot,tt/tot);
}

/*costruisce il vettore padre e stampa la rappresentazione compatta*/
void Compattamento(codice sequenze,vint padre,soluzioneMST *S,int n,int l)
{
	int i,j,dim,dim2=0;
	soluzioneMST Sol;
	vint visitati;
	
	visitati=malloc(n*sizeof(int));
	Sol=*S;
	visitati[dim2]=1;
	
	while(n!=1)
	{
		for(i=1; i<=Sol.nl; i++)
		{
			for(j=0;j<=dim;j++)/*lunghezza data dalla lista visitati*/
			{
				if(Sol.v1[i]==visitati[j])
				{
					dim2++;
					padre[Sol.v2[i]-2]=Sol.v1[i];
					visitati[dim2]=Sol.v2[i];
					Sol.v2[i]=3000;
					Sol.v1[i]=3000;
				}
				else if(Sol.v2[i]==visitati[j])
				{
					dim2++;
					padre[Sol.v1[i]-2]=Sol.v2[i];/*il vettore padre è ordinato per come è costruito sequenze*/
					visitati[dim2]=Sol.v1[i];
					Sol.v2[i]=3000;
					Sol.v1[i]=3000;
				}
			}
		}
		dim++;
		n--;
	}
	
	for(j=0;j<l;j++)
		printf("%c",sequenze[1][j]);
	printf("\n");
	
	for(i=0;i<Sol.nl;i++)
	{
		printf("%d ",padre[i]);
		for(j=0;j<l;j++)
		{
			if(sequenze[padre[i]][j]!=sequenze[i+2][j])
				printf("%d %c ",j,sequenze[i+2][j]);
		}
		printf("\n");
	}
	
	free(visitati);
}

void QuickSort(codice sequenze, int s, int d,int l)
{
  int q;

  if (s < d)
  {
    q = Partition(sequenze,s,d,l);
    QuickSort(sequenze,s,q-1,l);
    QuickSort(sequenze,q+1,d,l);
  }
}

int Partition(codice sequenze, int s, int d,int l)
{
	int d1; /* ultimo elemento della prima tabella (elementi <= pivot) */
	int d2; /* primo elemento a destra della seconda tabella  (elementi > pivot) */
	codice scambia;
	
	scambia = (codice) calloc(2,sizeof(vchar));
	if (scambia == NULL)
	{
		fprintf(stderr,"Errore nell'allocazione di una lista di codici!\n");
		exit(EXIT_FAILURE);
	}
	scambia[1] = (vchar) calloc(l,sizeof(char));
	if (scambia[1] == NULL)
	{
	  fprintf(stderr,"Errore nell'allocazione della %d -esimo codice!\n",1);
	  exit(EXIT_FAILURE);
	}
	
    d1 = s;
    for (d2 = s+1; d2 <= d; d2++)
			  if (strcmp(sequenze[d2],sequenze[s])<0)
			  {
				d1++;
				strcpy(scambia[1],sequenze[d2]);
				strcpy(sequenze[d2],sequenze[d1]);
				strcpy(sequenze[d1],scambia[1]);
			  }
			  
	strcpy(scambia[1],sequenze[d1]);
	strcpy(sequenze[d1],sequenze[s]);
	strcpy(sequenze[s],scambia[1]);
	
	return d1;
}

void DeallocaCodiceGenetico(codice *sequenze, int n)
{
	int i;
	
	for (i = 1; i <= n; i++)
	{
	  free((*sequenze)[i] );
	}
	
	free(*sequenze);
}