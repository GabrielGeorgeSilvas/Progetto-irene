#include "kruskal.h"

/* Crea una soluzione vuota */
void CreaSoluzione (int n, soluzioneMST *pS)
{
  pS->f = 0;
  pS->dim = n;
  pS->nl = 0;
  pS->v1 = (vint) calloc(pS->dim+1,sizeof(int));
  if (pS->v1 == NULL)
  {
    fprintf(stderr,"Errore nell'allocazione del vettore dei primi estremi!\n");
    exit(EXIT_FAILURE);
  }
  pS->v2 = (vint) calloc(pS->dim+1,sizeof(int));
  if (pS->v2 == NULL)
  {
    fprintf(stderr,"Errore nell'allocazione del vettore dei secondi estremi!\n");
    exit(EXIT_FAILURE);
  }
}

/* Distrugge la soluzione S */
void DistruggeSoluzione (soluzioneMST *pS)
{
  pS->f = 0;
  pS->dim = pS->nl = 0;
  free(pS->v1);
  pS->v1 = NULL;
  free(pS->v2);
  pS->v2 = NULL;
}

/* Stampa la soluzione */
void StampaSoluzione (soluzioneMST *pS)
{
  int i;

  printf("f* = %d\n",pS->f);
  printf("x* = ");
  for (i = 1; i <= pS->nl; i++)
    printf(" (%d,%d)",pS->v1[i],pS->v2[i]);
  printf("\n");
}


/* Risolve l'istanza G del MSTP con l'algoritmo di Kruskal restituendo la soluzione S */
void Kruskal (grafo *pG, soluzioneMST *pS)
{
  vposarco Pos;
  posarco pa, paMin;
  vint padre, num;
  int i;
  int mEst;
  int u, v;
  int cu, cv;

  /* Costruisce un heap indiretto (vettore di posizioni dei lati del grafo) */
  Pos = (vposarco) calloc(pG->m+1,sizeof(posarco));/*allocazione pos*/
  if (Pos == NULL)
  {
    fprintf(stderr,"Errore nell'allocazione dell'heap indiretto sui lati!\n");
    exit(EXIT_FAILURE);
  }
  for (i = 1, pa = primoarco(pG); !finearchi(pG, pa); i++, pa = succarco(pG, pa))/*carico pos*/
    Pos[i] = pa;

  mEst = pG->m;/*numero lati grafo*/
  creaheapindiretto(Pos,mEst,pG);

  /* Costruisce una foresta con bilanciamento sui vertici del grafo */
  padre = (vint) calloc(pG->n+1,sizeof(int));
  if (padre == NULL)
  {
    fprintf(stderr,"Errore nell'allocazione del vettore padre!\n");
    exit(EXIT_FAILURE);
  }
  num = (vint) calloc(pG->n+1,sizeof(int));
  if (num == NULL)
  {
    fprintf(stderr,"Errore nell'allocazione del vettore num!\n");
    exit(EXIT_FAILURE);
  }
  for (i = 1; i <= pG->n; i++)/*carico i vettori padre e num*/
  {
    padre[i] = i;
    num[i] = 1;
  }


  /* Finche' ci sono lati da esplorare in E' e la soluzione e' incompleta */
  while ( (mEst > 0) && (pS->nl < pG->n-1) )
  {
    /* Trova il lato di costo minimo in E' */
    paMin = Pos[1];

    /* Cancella il lato da E' */
    Pos[1] = Pos[mEst];
    mEst--;
    aggiornaheapindiretto(Pos,mEst,pG,1);

    /* Se i due estremi del lato stanno in componenti distinte della foresta con bilanciamento */
    leggeestremiarco(pG,paMin,&u,&v);
    cu = Find(u,padre,num);
    cv = Find(v,padre,num);
    if (cu != cv)
    {
      /* Aggiunge il lato alla soluzione corrente */
      pS->nl++;/*aumento la dimensione*/
      pS->v1[pS->nl] = u;
      pS->v2[pS->nl] = v;
      pS->f += leggecosto(pG,paMin);/*funzione aggiornata*/

      /* Unisce le due componenti della foresta */
      Union(cu,cv,padre,num);
    }
  }
  
  /* Dealloca l'heap indiretto e la foresta con bilanciamento */
  free(Pos);
  free(padre);
  free(num);
}


/* Crea un heap indiretto di lunghezza n attraverso il vettore di posizioni Pos sui lati del grafo G */
void creaheapindiretto (vposarco Pos, int n, grafo *pG)/*simile a quello già visto*/
{
  int i;

  for (i = n/2; i >= 1; i--)
    aggiornaheapindiretto(Pos,n,pG,i);
}

/* Scambia i valori di due variabili di tipo posarco a e b */
void Scambia (posarco *pa, posarco *pb)
{
  posarco temp;

  temp = *pa;
  *pa = *pb;
  *pb = temp;
}

/* Aggiorna l'heap indiretto di lunghezza n descritto dal vettore di posizioni Pos
   sui lati del grafo G a partire dalla posizione i */
void aggiornaheapindiretto (vposarco Pos, int n, grafo *pG, int i)
{
  int s, d;
  int iMin;
  int cs, cd, cMin;

  s = 2*i;
  d = 2*i+1;

  iMin = i;
  cMin = leggecosto(pG,Pos[i]);
  if (s <= n)
  {
    cs = leggecosto(pG,Pos[s]);
    if (cs < cMin)
    {
      iMin = s;
      cMin = cs;
    }
  }
  if (d <= n)
  {
    cd = leggecosto(pG,Pos[d]);
    if (cd < cMin)
    {
      iMin = d;
      cMin = cd;
    }
  }

  if (iMin != i)
  {
    Scambia(&Pos[iMin],&Pos[i]);
    aggiornaheapindiretto(Pos,n,pG,iMin);
  }
}


/* Trova la componente cui appartiene l'elemento i nella foresta con bilanciamento descritta da padre e num */
int Find (int i, vint padre, vint num)
{
	/*abbiamo usato la compressione dei cammini*/
  int j, r, pj;

  j = i;
  while (padre[j] != j)
    j = padre[j];
  r = j;

  j = i;
  while (j != r)
  {
    pj = padre[j];
    padre[j] = r;
    j = pj;
  }

  return j;
}


/* Fonde le componenti c1 e c2 nella foresta con bilanciamento descritta da padre e num
   (non controlla che siano diverse!) */
void Union(int c1, int c2, vint padre, vint num)
{
  if (num[c1] < num[c2])
  {
    padre[c1] = c2;
    num[c2] += num[c1];
    num[c1] = 0;
  }
  else
  {
    padre[c2] = c1;
    num[c1] += num[c2];
    num[c2] = 0;
  }
}
