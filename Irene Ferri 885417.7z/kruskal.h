#ifndef __kruskal_h
#define __kruskal_h

/* Direttive */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


#define ROW_LENGTH 256
#include "listaarchi.h"
#include "grafo-la.h"


typedef int * vint;
typedef int * vnodo;
typedef posarco * vposarco;

typedef struct _soluzioneMST soluzioneMST;
struct _soluzioneMST
{
  int f;/*valore corrente*/
  int dim;/*dimensione tabelle*/
  int nl;/*valore corrente*/
  vnodo v1;/*tabella 1*/
  vnodo v2;/*tabella 2*/
};

/* Crea una soluzione vuota */
void CreaSoluzione (int n, soluzioneMST *pS);

/* Distrugge la soluzione S */
void DistruggeSoluzione (soluzioneMST *pS);

/* Stampa la soluzione */
void StampaSoluzione (soluzioneMST *pS);

/* Risolve l'istanza G del MSTP con l'algoritmo di Kruskal restituendo la soluzione S */
void Kruskal (grafo *pG, soluzioneMST *pS);

/* Crea un heap indiretto di lunghezza n attraverso il vettore di posizioni Pos sui lati del grafo G */
void creaheapindiretto (vposarco Pos, int n, grafo *pG);

/* Aggiorna l'heap indiretto di lunghezza n descritto dal vettore di posizioni Pos
   sui lati del grafo G a partire dalla posizione i */
void aggiornaheapindiretto (vposarco Pos, int n, grafo *pG, int i);

/* Trova la componente cui appartiene l'elemento i nella foresta con bilanciamento descritta da padre e num */
int Find (int i, vint padre, vint num);

/* Unisce le componenti radicate in c1 e c2 nella foresta con bilanciamento descritta da padre e num
   (non controlla che siano diverse!) */
void Union (int c1, int c2, vint padre, vint num);

/* Scambia i valori di due variabili di tipo posarco a e b */
void Scambia (posarco *pa, posarco *pb);

#endif