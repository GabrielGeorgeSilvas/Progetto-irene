#include "listaarchi.h"

listaarchi crealistaarchi ()
{
  listaarchi L = (listaarchi) malloc(sizeof(arco));
  if (L == NULL)
  {
    fprintf(stderr,"Memoria insufficiente per allocare un arco!\n");
    exit(EXIT_FAILURE);
  }

  L->orig = 0;
  L->dest = 0;
  L->costo = 0;

  L->succ = L;
  L->pred = L;

  return L;
}


void distruggelistaarchi (listaarchi *pL)
{
  posarco p;

  while (!listaarchivuota(*pL))
  {
    p = primolistaarchi(*pL);
    *pL = canclistaarchi(*pL,&p);
  }
  free(*pL);
  *pL = NULL;
}


void leggearco (listaarchi L, posarco p, nodo *porig, nodo *pdest, int *pcosto)
{
  *porig = p->orig;
  *pdest = p->dest;
  *pcosto = p->costo;
}


listaarchi scrivearco (listaarchi L, posarco p, nodo orig, nodo dest, int costo)
{
  p->orig = orig;
  p->dest = dest;
  p->costo = costo;
  return L;
}


boolean listaarchivuota (listaarchi L)
{
  return (L->succ == L);
}


posarco primolistaarchi (listaarchi L)
{
  return L->succ;
}


posarco ultimolistaarchi (listaarchi L)
{
  return L->pred;
}


posarco succlistaarchi (listaarchi L, posarco p)
{
  return p->succ;
}


posarco preclistaarchi (listaarchi L, posarco p)
{
  return p->pred;
}


boolean finelistaarchi (listaarchi L, posarco p)
{
  return (p == L);
}

int confrontoRappresentanteArchi(char **sequenze,int o1,int d1,int o2,int d2,int l)
{
	int i=0,j,k=0;
	
	char *c1,*c2;
	c1=malloc(l*sizeof(char));
	c2=malloc(l*sizeof(char));
	
	for(j=0;j<l;j++)
	{
		if(sequenze[o1][j]!=sequenze[d1][j])
		{
			c1[i]=sequenze[d1][j];
			i++;
		}
		if(sequenze[o2][j]!=sequenze[d2][j])
		{
			c2[k]=sequenze[d2][j];
			k++;
		}
	}
	if(i<=k)
	{
		if(strncmp(c1,c2,i)>0)
			return 1;
	}				
	else if(k<i) 
	{
		if(strncmp(c1,c2,k)>0)

			return 1;		
	}

	return 0;
	free(c1);
	free(c2);
}

posarco cercaMaggiore(listaarchi L,nodo o,nodo d,int c,char **sequenze,int l)
{
	posarco q=L->succ;
	
	while((q!=L)&&(q->costo)<=c)/*finchè non è vuota o non trovi un valore maggiore del costo in ingresso*/
	{
		if(q->costo==c)
		{
			if(confrontoRappresentanteArchi(sequenze,q->orig,q->dest,o,d,l)==1)
				return q;
		}
		q=q->succ;
	}

	return q;
}

listaarchi inslistaarchi (listaarchi L, posarco p, nodo orig, nodo dest, int costo)
{	
  posarco q = (posarco) malloc(sizeof(arco));
  if (q == NULL)
  {
    fprintf(stderr,"Memoria insufficiente per allocare un arco!\n");
    exit(EXIT_FAILURE);
  }
  
  q->orig = orig;
  q->dest = dest;
  q->costo = costo;
  q->succ = p->succ;
  q->pred = p;
  q->succ->pred = q;
  p->succ = q;
  return L;
}

listaarchi canclistaarchi (listaarchi L, posarco *pp)
{
  posarco p = *pp;

  *pp = p->succ;
  p->pred->succ = p->succ;
  p->succ->pred = p->pred;
  free(p);

  return L;
}
