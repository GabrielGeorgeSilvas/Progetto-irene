#ifndef __listaarchi_h
#define __listaarchi_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRUE  1
#define FALSE 0
#define boolean int


typedef struct _arco arco;
typedef arco* listaarchi;
typedef arco* posarco;
typedef int nodo;
typedef char *vchar;

#define NO_ARC   NULL
#define R_MAX 1001

struct _arco
{
  nodo    orig, dest;
  int     costo;
  posarco succ, pred;
};


listaarchi crealistaarchi ();

void distruggelistaarchi (listaarchi *pL);

void leggearco (listaarchi L, posarco p, nodo *porig, nodo *pdest, int *pcosto);

listaarchi scrivearco (listaarchi L, posarco p, nodo orig, nodo dest, int costo);

posarco primolistaarchi (listaarchi L);

posarco ultimolistaarchi (listaarchi L);

boolean finelistaarchi (listaarchi L, posarco p);

boolean listaarchivuota (listaarchi L);

posarco preclistaarchi (listaarchi L, posarco p);

posarco succlistaarchi (listaarchi L, posarco p);

/*metodo per confrontare la stringa rappresentativa all'inserimento 
nel caso il peso dell'arco sia uguale ha uno gà presente nella lista*/
int confrontoRappresentanteArchi(char **sequenze,int o1,int d1,int o2,int d2,int l);

posarco cercaMaggiore(listaarchi L,nodo o,nodo d,int c,char **sequenze,int l);

/*inserisco in testa*/
listaarchi inslistaarchi (listaarchi L, posarco p, nodo orig, nodo dest, int costo);

listaarchi canclistaarchi (listaarchi L, posarco *pp);

#endif
