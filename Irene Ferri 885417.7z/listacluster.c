#include "listacluster.h"

elemento *crealista_cluster ()
{	
	return NULL;
}

elemento *new_elemento(elemento *C,int r,int v)
{
	elemento *q,*aux;
	aux=C;
	q = (elemento*)calloc(1,sizeof(elemento));
	if (q == NULL)
    {
		fprintf(stderr,"Errore nell'allocazione dell'elemento %d!\n",r);
		exit(EXIT_FAILURE);
	}
	
	q->rappresentante=r;
	q->valore=v;
	q->cardinalita=0;
	q->next=NULL;

	if(C==NULL)
	{
		C=q;
	}
	else
	{
		while(aux->next)aux=aux->next;
		aux->next=q;
	}
	
	return C;
}

int confrontoRappresentante(char **sequenze,int prima,int dopo,int v,int l)
{
	int i=0,j,k=0;
	
	char *c1,*c2;
	c1=malloc(l*sizeof(char));
	c2=malloc(l*sizeof(char));
	
	for(j=0;j<l;j++)
	{
		if(sequenze[prima][j]!=sequenze[v][j])
		{
			c1[i]=sequenze[v][j];
			i++;
		}
		if(sequenze[dopo][j]!=sequenze[v][j])
		{
			c2[k]=sequenze[v][j];
			k++;
		}
	}
	if(i<=k)
	{
		if(strncmp(c1,c2,i)>0)
			return dopo;
	}				
	else if(k<i) 
	{
		if(strncmp(c1,c2,k)>0)
			return dopo;	
	}
	return prima;
	free(c1);
	free(c2);
}

elemento *caricalista_cluster(int s,int n,int l,char **sequenze)
{
	int k,i,j,diff,rapp,min;
	
	elemento *q=crealista_cluster();
	for(k=s+1;k<=n;k++)
	{
		min=3000;
		for(i=1;i<=s;i++)
		{
			diff=0;
			for(j=0;j<l;j++)
			{
				if(sequenze[i][j]!=sequenze[k][j])
					diff++;
							
			}
			if(diff<=min)
			{
				if(diff==min)
				{
					rapp=confrontoRappresentante(sequenze,rapp,i,k,l);
				}
				else
				{
					min=diff;
					rapp=i;
				}	
			}
		}
		q=new_elemento(q,rapp,k);
	}
	return q;
}

elemento *setCardinalita(elemento *q,int card,int r)
{
	elemento *aux;
	
	for( aux=q; aux!= NULL; aux = aux->next )
	{
		if(aux->rappresentante==r)
			aux->cardinalita=card;
	}
	
	return q;
}

elemento *riallocamento_rappresentante(elemento *q,int s,char **sequenze,int l)
{
	int i,j,k,x,tot,min;
	int *listavalori;
	elemento *aux1;
	
	listavalori=malloc(MAX*sizeof(int));
	
	for(i=1;i<=s;i++)
	{
		min=30000;
		j=0;
		listavalori[j]=i;
		for ( aux1=q; aux1!= NULL; aux1 = aux1->next )
		{
			if(aux1->rappresentante==i)
			{
				j++;
				listavalori[j]=aux1->valore;
			}
		}
		x=lunghezza_valori(q,i);
		q=setCardinalita(q,x+1,i);
		for(j=0;j<=x;j++)
		{
			tot=calcolaDiffTot(listavalori,listavalori[j],x,sequenze,l);
			if(tot<min)/*in caso tot=min prende già il minimo indice per come è costruito il problema*/
			{
				min=tot;
				k=listavalori[j];
			}
		}
		if(k!=i)/*nuovo rappresentante, se k=i il rappresentante iniziale ha l'indice minimo*/
		{
			q=switchRappresentante(q,k,i);
		}
	}
	
	return q;
	free(listavalori);
}

int lunghezza_valori(elemento *q,int i)
{
	int l=0;
	elemento *aux;
	
	for ( aux=q; aux!= NULL; aux = aux->next )
	{
		if(aux->rappresentante==i)
			{
				l++;
			}
	}
	return l;
}

int calcolaDiffTot(int *listavalori,int v,int x,char **sequenze,int l)
{
	int i,j,tot=0;
	
	for(i=0;i<=x;i++)
	{
		for(j=0;j<l;j++)
		{
			if(sequenze[v][j]!=sequenze[listavalori[i]][j])
				tot++;
		}
	}
	
	return tot;
}

elemento *switchRappresentante(elemento *q,int nuovo,int vecchio)
{
	elemento *aux;
	
	for ( aux=q; aux!= NULL; aux = aux->next )
	{
		if((aux->rappresentante==vecchio)&&(aux->valore==nuovo))
		{
			aux->rappresentante=nuovo;
			aux->valore=vecchio;
		}
		else if(aux->rappresentante==vecchio)
			aux->rappresentante=nuovo;
	}
	
	return q;
}

int search_rappresentante(elemento *q,int j)
{
	int k=0;
	elemento *aux;
	
	for ( aux = q; aux!= NULL; aux = aux->next )
	{
		if(aux->valore==j)
		{
			return k=aux->rappresentante;
		}
			
	}
	for ( aux = q; aux!= NULL; aux = aux->next )
	{
		if(aux->rappresentante==j)
		{
			return k=aux->rappresentante;
		}		
	}
	return k;
}

int search_cardinalita(elemento *q,int j)
{
	int k=0;
	elemento *aux;
	for ( aux = q; aux!= NULL; aux = aux->next )
	{
		if(aux->rappresentante==j)
			return k=(aux->cardinalita);
	}
	return k;
}

void stampalista_cluster(elemento *C,int s)
{
	elemento *q,*aux,*aux1,*aux2;
	int i,j,x,r1,r2;
	int *V1,*V2,*V3;
	
	V1=malloc(s*sizeof(int));
	V2=malloc(s*sizeof(int));
	V3=malloc(MAX*sizeof(int));
	
	q=C;
	aux=C;
	aux2=C;
	for (j=1;j<=s;j++)
	{
		r1=search_rappresentante(q,j);/*non funge*/
		V1[j]=r1;
		
		r2=search_cardinalita(aux,V1[j]);/*non funge*/
		V2[j]=r2;
		
	}
	OrdineCardinalitaDecrescente(V1,V2,s);
	for (j=1;j<=s;j++)
	{
		i=1;
		printf("Cluster %d rappresentante %d elementi ",j,V1[j]);
		for ( aux1 = C; aux1!= NULL; aux1 = aux1->next )
		{
			if(aux1->rappresentante==V1[j])
			{
				V3[i]=aux1->valore;	
				i++;
			}
		}
		x=lunghezza_valori(aux2,V1[j]);
		OrdinaValori(V3,x);
		for(i=1;i<=x;i++)
			printf("%d ",V3[i]);
		printf("(%d)\n",V2[j]);
	}
	
	free(V1);
	free(V2);
	free(V3);
}


void ScambiaInteri (int *a, int *b)
{
  int temp;

  temp = *a;
  *a = *b;
  *b = temp;
}

void OrdinaValori(int *V3,int n)
{
	int i,j;
	
	for(i=1;i<=n;i++)
	{
		for(j=i+1;j<=n;j++)
		{
			if(V3[i]>V3[j])
				ScambiaInteri(&V3[i],&V3[j]);
		}
	}
}

void OrdineCardinalitaDecrescente(int *V1,int *V2,int s)
{
	int i,j;
	
	for(i=1;i<=s;i++)
	{
		for(j=i+1;j<=s;j++)
		{
			if(V2[i]<V2[j])
			{
				ScambiaInteri(&V2[i],&V2[j]);
				ScambiaInteri(&V1[i],&V1[j]);
			}
			else if((V2[i]==V2[j])&&(V1[i]>V1[j]))
			{
				ScambiaInteri(&V2[i],&V2[j]);
				ScambiaInteri(&V1[i],&V1[j]);
			}
		}
		
	}
}

void deleteListacluster(elemento *q)  
{  
	elemento *p,*aux;
	
	p=q;
	
    if (p == NULL) return;  
  
    while(p!=NULL)
	{
		aux=p->next;
		free(p);
		p=aux;
	}
} 