#ifndef __listacluster_h
#define __listacluster_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ROW_LENGTH 256

#define boolean int
#define TRUE  1
#define FALSE 0

#define NO_ELEMENT NULL
#define NO_LIST    NULL  
#define MAX 15+1 /*valore massimo elementi di un cluster*/


typedef struct _elemento elemento;

struct _elemento 
{
  int rappresentante;
  int valore;
  int cardinalita;
  elemento *next;
};

/*creo una lista cluster vuota*/
elemento *crealista_cluster ();

/*crea un nuovo elemento*/
elemento *new_elemento(elemento *C, int r,int v);

/*carico la lista */
elemento *caricalista_cluster(int s,int n,int l,char **sequenze);

/*serve per modificare la cardinalita'*/
elemento *setCardinalita(elemento *q,int card,int r);

/*rialloca il rappresentante dei diversi cluster*/
elemento *riallocamento_rappresentante(elemento *q,int s,char **sequenze,int l);

/*restituisce per un rappresentante quanti elementi ha*/
int lunghezza_valori(elemento *q,int i);

/*esegue la differenza tra stringhe e la ritorna, la differenza è tra il rappresentante e tutti i cuoi valori*/
int calcolaDiffTot(int *listavalori,int v,int x,char **sequenze,int l);

/*scambia il rappresentante della lista*/
elemento *switchRappresentante(elemento *q,int nuovo,int vecchio);

/*cerca il rappresentante*/
int search_rappresentante(elemento *q,int j);

/*cerca la cardinalita'*/
int search_cardinalita(elemento *q,int j);

/*confronto il vecchio e il nuovo rappresentante in base all'ordine della stringa rappresentativa*/
int confrontoRappresentante(char **sequenze,int prima,int dopo,int v,int l);

/*stampa*/
void stampalista_cluster(elemento *C,int s);

/*scambia valori interi*/
void ScambiaInteri (int *a, int *b);

/*buvvlesort su un vettore di interi*/
void OrdinaValori(int *V3,int n);


/*bubblesort su due vettori di interi*/
void OrdineCardinalitaDecrescente(int *V1,int *V2,int s);

/*dealloca la lista cluster*/
void deleteListacluster(elemento *q);

#endif
